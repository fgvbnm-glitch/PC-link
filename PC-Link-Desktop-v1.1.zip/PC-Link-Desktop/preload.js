
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('pcLink', {
  getStats: () => ipcRenderer.invoke('pc-link:stats'),
  setNotifications: enabled => ipcRenderer.invoke('pc-link:notification-setting', enabled),
  testNotification: () => ipcRenderer.invoke('pc-link:test-notification'),
  openLink: url => ipcRenderer.invoke('pc-link:open-link', url),
  onStats: callback => {
    if (typeof callback !== 'function') return;
    const listener = (_event, stats) => callback(stats);
    ipcRenderer.on('pc-link:stats-update', listener);
    return () => ipcRenderer.removeListener('pc-link:stats-update', listener);
  }
});
