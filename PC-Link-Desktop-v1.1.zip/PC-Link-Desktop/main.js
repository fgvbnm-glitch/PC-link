
const { app, BrowserWindow, ipcMain, Notification, shell } = require('electron');
const os = require('os');
const path = require('path');
let win;
let lastCpu = os.cpus();
let notificationsOn = false;
let lastNotice = 0;

function cpuPercent() {
  const now = os.cpus();
  let idle = 0, total = 0;
  for (let i = 0; i < now.length; i++) {
    const a = lastCpu[i]?.times || now[i].times;
    const b = now[i].times;
    const idleDiff = b.idle - a.idle;
    const totalDiff = Object.keys(b).reduce((sum, k) => sum + b[k] - a[k], 0);
    idle += idleDiff; total += totalDiff;
  }
  lastCpu = now;
  return total ? Math.max(0, Math.min(100, Math.round(100 * (1 - idle / total)))) : 0;
}
function getStats() {
  const total = os.totalmem();
  const free = os.freemem();
  return {
    computer: os.hostname(),
    platform: `${os.type()} ${os.release()}`,
    architecture: os.arch(),
    cpu: cpuPercent(),
    memoryUsed: Math.round((total-free)/1024/1024/1024*10)/10,
    memoryTotal: Math.round(total/1024/1024/1024*10)/10,
    uptimeHours: Math.round(os.uptime()/360)/10,
    cores: os.cpus().length,
    network: Object.values(os.networkInterfaces()).flat().some(x => x && !x.internal) ? 'Network interface available' : 'No network interface detected',
    checkedAt: new Date().toISOString()
  };
}
function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 820, minWidth: 760, minHeight: 620,
    backgroundColor: '#0b1220',
    title: 'PC Link',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, 'public', 'index.html'));
}
app.whenReady().then(() => {
  ipcMain.handle('pc-link:stats', () => getStats());
  ipcMain.handle('pc-link:notification-setting', (_e, enabled) => {
    notificationsOn = Boolean(enabled);
    return notificationsOn;
  });
  ipcMain.handle('pc-link:test-notification', () => {
    if (Notification.isSupported()) new Notification({ title: 'PC Link', body: 'Desktop notifications are working.' }).show();
    return Notification.isSupported();
  });
  ipcMain.handle('pc-link:open-link', (_e, url) => {
    if (typeof url === 'string' && /^https:\/\/(github\.com|platform\.openai\.com)\//.test(url)) shell.openExternal(url);
  });
  createWindow();
  const timer = setInterval(() => {
    if (!win || win.isDestroyed()) return;
    const stats = getStats();
    win.webContents.send('pc-link:stats-update', stats);
    if (notificationsOn && stats.memoryTotal > 0 && (stats.memoryUsed / stats.memoryTotal) > 0.92 && Date.now()-lastNotice > 300000) {
      lastNotice = Date.now();
      if (Notification.isSupported()) new Notification({ title: 'PC Link: High memory use', body: 'Your PC is using more than 92% of its memory.' }).show();
    }
  }, 5000);
  app.on('before-quit', () => clearInterval(timer));
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
