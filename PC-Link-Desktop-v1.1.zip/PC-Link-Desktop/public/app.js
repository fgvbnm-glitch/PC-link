
const $ = id => document.getElementById(id);
const logList = $('logList');
function log(message) {
  const item = document.createElement('p');
  item.className = 'log-entry';
  item.textContent = `${new Date().toLocaleTimeString()} · ${message}`;
  logList.prepend(item);
  while (logList.children.length > 12) logList.lastChild.remove();
}
function setMeter(id, value) { $(id).style.width = `${Math.max(0, Math.min(100, value))}%`; }
function render(s) {
  $('computer').textContent = s.computer;
  $('platform').textContent = `${s.platform} · ${s.architecture}`;
  $('cpu').textContent = `${s.cpu}%`; setMeter('cpuBar', s.cpu);
  const pct = Math.round(s.memoryUsed / s.memoryTotal * 100);
  $('ram').textContent = `${s.memoryUsed} / ${s.memoryTotal} GB`;
  $('ramPct').textContent = `${pct}% used`; setMeter('ramBar', pct);
  $('uptime').textContent = `${s.uptimeHours} hrs`;
  $('cores').textContent = `${s.cores} logical CPU cores`;
  $('network').textContent = s.network;
  $('lastSync').textContent = new Date(s.checkedAt).toLocaleTimeString();
  $('updated').textContent = new Date(s.checkedAt).toLocaleTimeString();
}
async function init() {
  try { render(await window.pcLink.getStats()); }
  catch { log('Could not read local PC stats.'); }
  window.pcLink.onStats(render);
}
document.querySelectorAll('.category').forEach(box => {
  box.addEventListener('change', () => {
    const chosen = [...document.querySelectorAll('.category:checked')].map(x => x.value);
    localStorage.setItem('pcLinkCategories', JSON.stringify(chosen));
    log(`${box.parentElement.textContent.trim()} ${box.checked ? 'allowed' : 'not allowed'} (local preference)`);
  });
});
try {
  const saved = JSON.parse(localStorage.getItem('pcLinkCategories') || 'null');
  if (saved) document.querySelectorAll('.category').forEach(x => x.checked = saved.includes(x.value));
} catch {}
$('sharingToggle').addEventListener('change', e => {
  localStorage.setItem('pcLinkFutureConsent', String(e.target.checked));
  log(`Future sharing preference ${e.target.checked ? 'enabled' : 'disabled'}; no data was sent`);
});
$('sharingToggle').checked = localStorage.getItem('pcLinkFutureConsent') === 'true';
$('notificationsToggle').addEventListener('change', async e => {
  await window.pcLink.setNotifications(e.target.checked);
  log(`Local desktop notifications ${e.target.checked ? 'enabled' : 'disabled'}`);
});
$('testNotification').addEventListener('click', async () => {
  const ok = await window.pcLink.testNotification();
  log(ok ? 'Test notification displayed' : 'Notifications are not supported on this system');
});
$('clearLog').addEventListener('click', () => { logList.replaceChildren(); log('Activity log cleared'); });
$('githubBtn').addEventListener('click', () => window.pcLink.openLink('https://github.com/'));
init();
