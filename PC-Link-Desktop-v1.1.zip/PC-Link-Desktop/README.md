# PC Link Desktop v1.1

A Windows-friendly Electron desktop dashboard. It reads a small set of local system stats and displays them on this computer.

## Run it

1. Install Node.js (LTS) on the PC.
2. Extract this folder.
3. Open a terminal in this folder.
4. Run `npm install`.
5. Run `npm start`.

## Build Windows installers

Run `npm run dist`. Electron Builder creates Windows installer/portable build output in `dist/`.

## Included

- Desktop app window (Electron)
- Local CPU estimate, RAM use, computer name, OS, CPU core count, uptime, and network-interface presence
- Five-second local refresh
- Optional local notification for high RAM use
- Local-only category preferences and future-sharing consent preference
- Local activity log
- Secure Electron defaults: context isolation, sandbox, no Node integration in the page

## Important limits

This version does **not** upload PC stats, connect to a cloud service, connect to a ChatGPT plugin, read battery percentage, or run as a Windows service. The network field only checks whether a non-loopback network interface exists; it does not inspect traffic. The sharing switch records your future consent preference only. Nothing is transmitted.

The app can continue updating while the display is off only if the computer stays awake and the app remains running. Windows sleep, shutdown, or closing the app stops updates. Remote status from another device and the ChatGPT plugin need a separate secure backend and authenticated connector in a future version.

Never add keylogging, password collection, private-message capture, microphone recording, or hidden screenshots. Keep sharing opt-in and limited to clearly selected status fields.
